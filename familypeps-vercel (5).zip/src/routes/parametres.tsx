import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { ColorPicker } from "@/components/forms";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { PageHeader } from "@/components/ui/empty";
import { useFamilyStore } from "@/lib/family/store";
import { cloudConfigHint, isCloudConfigured, testCloudConnection } from "@/lib/family/supabase";
import {
  createFamilyCloud,
  joinFamilyCloud,
  leaveFamilyCloud,
  onSyncStatus,
  type SyncStatus,
} from "@/lib/family/sync";
import type { MemberColor } from "@/lib/family/types";

export const Route = createFileRoute("/parametres")({ component: SettingsPage });

function SettingsPage() {
  const store = useFamilyStore();
  const s = store.settings;
  const [joinCode, setJoinCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [syncStatus, setSyncStatus] = useState<SyncStatus>("off");
  const [syncMsg, setSyncMsg] = useState<string | undefined>();
  const cloudOk = isCloudConfigured();

  useEffect(() => onSyncStatus((st, msg) => {
    setSyncStatus(st);
    setSyncMsg(msg);
  }), []);

  function requestNotif() {
    if (typeof Notification === "undefined") {
      toast.error("Les notifications ne sont pas disponibles ici.");
      return;
    }
    void Notification.requestPermission().then((p) => {
      store.updateSettings({ remindersEnabled: p === "granted" });
      toast.success(p === "granted" ? "Rappels activés" : "Notifications refusées");
    });
  }

  return (
    <div className="flex flex-col gap-5">
      <PageHeader title="Paramètres" subtitle="Tout est modifiable. Rien n'est figé." />

      <section className="rounded-3xl bg-surface p-5 card-shadow">
        <h2 className="mb-4 font-display text-xl font-semibold">Application</h2>
        <div className="flex flex-col gap-3">
          <Field label="Nom de l'application">
            <Input
              value={s.appName}
              onChange={(e) => store.updateSettings({ appName: e.target.value })}
            />
          </Field>
          <Field label="Nom de famille (accueil)">
            <Input
              value={s.familyName || ""}
              onChange={(e) => store.updateSettings({ familyName: e.target.value })}
              placeholder="Lamhamdi"
            />
          </Field>
          <Field label="Ville (météo)">
            <Input
              value={s.city}
              onChange={(e) => store.updateSettings({ city: e.target.value })}
            />
          </Field>
          <Field label="Je suis">
            <Select
              value={s.currentMemberId}
              onChange={(e) => store.updateSettings({ currentMemberId: e.target.value })}
            >
              {store.members.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.firstName}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="La semaine commence">
            <Select
              value={String(s.weekStartsOn)}
              onChange={(e) =>
                store.updateSettings({ weekStartsOn: Number(e.target.value) as 0 | 1 })
              }
            >
              <option value="1">Lundi</option>
              <option value="0">Dimanche</option>
            </Select>
          </Field>
        </div>
      </section>

      <section className="rounded-3xl bg-surface p-5 card-shadow">
        <h2 className="mb-4 font-display text-xl font-semibold">Rappels</h2>
        <label className="mb-3 flex min-h-11 items-center justify-between gap-3">
          <span className="font-semibold">Activer les rappels</span>
          <input
            type="checkbox"
            className="size-5 accent-primary"
            checked={s.remindersEnabled}
            onChange={(e) => store.updateSettings({ remindersEnabled: e.target.checked })}
          />
        </label>
        <Field label="Rappel par défaut">
          <Select
            value={String(s.defaultReminderMinutes)}
            onChange={(e) =>
              store.updateSettings({ defaultReminderMinutes: Number(e.target.value) })
            }
          >
            <option value="15">15 minutes avant</option>
            <option value="60">1 heure avant</option>
            <option value="120">2 heures avant</option>
            <option value="1440">La veille</option>
          </Select>
        </Field>
        <Button className="mt-3" variant="outline" onClick={requestNotif}>
          Autoriser les notifications du navigateur
        </Button>
      </section>

      <section className="rounded-3xl bg-surface p-5 card-shadow">
        <h2 className="mb-4 font-display text-xl font-semibold">Catégories</h2>
        <ul className="flex flex-col gap-4">
          {store.categories.map((c) => (
            <li key={c.id} className="flex flex-col gap-2 rounded-2xl bg-surface-2 p-3">
              <div className="flex items-center gap-2">
                <Input
                  value={c.name}
                  onChange={(e) => store.updateCategory(c.id, { name: e.target.value })}
                />
                {!c.builtin ? (
                  <Button variant="ghost" size="sm" onClick={() => store.removeCategory(c.id)}>
                    Retirer
                  </Button>
                ) : null}
              </div>
              <ColorPicker
                value={c.color}
                onChange={(color: MemberColor) => store.updateCategory(c.id, { color })}
              />
            </li>
          ))}
        </ul>
        <Button
          className="mt-3"
          variant="outline"
          onClick={() =>
            store.addCategory({ name: "Nouvelle catégorie", icon: "star", color: "turquoise" })
          }
        >
          Créer une catégorie
        </Button>
      </section>

      <section className="rounded-3xl bg-surface p-5 card-shadow">
        <h2 className="mb-2 font-display text-xl font-semibold">Famille connectée (temps réel)</h2>
        <p className="mb-3 text-sm text-muted">
          Partagez un code pour que tous les téléphones voient les mêmes données en direct.
          Sans code, l&apos;app reste 100&nbsp;% locale sur cet appareil.
        </p>
        {!cloudOk ? (
          <div className="rounded-2xl bg-warn/15 px-3 py-3 text-sm text-ink">
            <p className="font-semibold">Backend non vu par l&apos;app</p>
            <p className="mt-1 text-muted">{cloudConfigHint()}</p>
            <p className="mt-2 text-muted">
              Les variables Netlify sont injectées <strong>au build</strong>. Après les avoir ajoutées,
              il faut un <strong>nouveau déploiement</strong> (Deploys → Trigger deploy → Deploy site).
            </p>
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            <p className="text-sm">
              État :{" "}
              <strong>
                {syncStatus === "synced"
                  ? "Connecté · synchronisé"
                  : syncStatus === "connecting"
                    ? "Connexion…"
                    : syncStatus === "error"
                      ? `Erreur${syncMsg ? ` · ${syncMsg}` : ""}`
                      : s.cloudSync && s.familyCode
                        ? "En attente"
                        : "Local uniquement — crée ou rejoins une famille"}
              </strong>
            </p>
            <Button
              variant="outline"
              size="sm"
              disabled={busy}
              onClick={async () => {
                setBusy(true);
                try {
                  const res = await testCloudConnection();
                  if ("ok" in res) toast.success(`Supabase OK · ${res.url}`);
                  else toast.error(res.error, { duration: 10000 });
                } finally {
                  setBusy(false);
                }
              }}
            >
              Tester la connexion cloud
            </Button>
            {s.familyCode ? (
              <div className="rounded-2xl bg-member-turquoise-soft px-4 py-3">
                <p className="text-xs font-semibold text-muted">Code famille</p>
                <p className="font-display text-2xl font-bold tracking-wider text-member-turquoise">
                  {s.familyCode}
                </p>
                <p className="mt-1 text-xs text-muted">
                  À donner aux autres membres. Ils collent ce code dans « Rejoindre ».
                </p>
                <Button
                  className="mt-3"
                  variant="outline"
                  size="sm"
                  disabled={busy}
                  onClick={async () => {
                    setBusy(true);
                    try {
                      await leaveFamilyCloud();
                      toast.success("Déconnecté du cloud — données locales conservées");
                    } finally {
                      setBusy(false);
                    }
                  }}
                >
                  Quitter le cloud
                </Button>
              </div>
            ) : (
              <>
                <Button
                  disabled={busy}
                  onClick={async () => {
                    setBusy(true);
                    try {
                      const res = await createFamilyCloud();
                      if ("error" in res) toast.error(res.error);
                      else toast.success(`Famille créée · code ${res.code}`);
                    } finally {
                      setBusy(false);
                    }
                  }}
                >
                  Créer une famille partagée
                </Button>
                <Field label="Rejoindre avec un code">
                  <div className="flex gap-2">
                    <Input
                      value={joinCode}
                      onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                      placeholder="PEPS-XXXX"
                      className="font-mono uppercase"
                    />
                    <Button
                      variant="outline"
                      disabled={busy || !joinCode.trim()}
                      onClick={async () => {
                        setBusy(true);
                        try {
                          const res = await joinFamilyCloud(joinCode);
                          if ("error" in res) toast.error(res.error);
                          else toast.success("Connecté à la famille");
                        } finally {
                          setBusy(false);
                        }
                      }}
                    >
                      Rejoindre
                    </Button>
                  </div>
                </Field>
              </>
            )}
          </div>
        )}
      </section>

      <section className="rounded-3xl bg-surface p-5 card-shadow">
        <h2 className="mb-2 font-display text-xl font-semibold">Données</h2>
        <p className="mb-4 text-sm text-muted">
          En local, tout reste sur cet appareil. Avec un code famille, le cloud synchronise aussi.
        </p>
        <div className="flex flex-wrap gap-2">
          <Button
            variant="outline"
            onClick={() => {
              if (confirm("Recharger les données d'exemple ? Vos modifications seront perdues.")) {
                store.resetDemo();
                toast.success("Exemple rechargé");
              }
            }}
          >
            Recharger l'exemple
          </Button>
          <Button
            variant="danger"
            onClick={() => {
              if (confirm("Tout supprimer définitivement ?")) {
                store.wipeAll();
                toast.success("Données effacées");
              }
            }}
          >
            Tout supprimer
          </Button>
        </div>
      </section>
    </div>
  );
}
