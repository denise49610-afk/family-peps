import { createFileRoute } from "@tanstack/react-router";
import { Backpack, Plus, Upload } from "lucide-react";
import { useEditors } from "@/components/editors-context";
import { MemberAvatar } from "@/components/member-avatar";
import { Button } from "@/components/ui/button";
import { EmptyState, PageHeader } from "@/components/ui/empty";
import { weekdayLabel } from "@/lib/family/dates";
import { useFamilyStore } from "@/lib/family/store";

export const Route = createFileRoute("/plannings")({ component: PlanningsPage });

function PlanningsPage() {
  const schedules = useFamilyStore((s) => s.schedules);
  const members = useFamilyStore((s) => s.members);
  const { open } = useEditors();

  return (
    <div>
      <PageHeader
        title="Plannings"
        subtitle="Saisie manuelle ou import photo / PDF, puis confirmation."
        action={
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => open({ type: "import-schedule" })}>
              <Upload className="size-4" />
              Importer
            </Button>
            <Button onClick={() => open({ type: "schedule" })}>
              <Plus className="size-4" />
              Créer
            </Button>
          </div>
        }
      />
      {schedules.length === 0 ? (
        <EmptyState
          icon={Backpack}
          title="Aucun planning"
          hint="Ajoutez l'emploi du temps d'un enfant, ou importez une photo du planning."
          action={
            <Button onClick={() => open({ type: "import-schedule" })}>Importer un planning</Button>
          }
        />
      ) : (
        <div className="flex flex-col gap-4">
          {schedules.map((sch) => {
            const member = members.find((m) => m.id === sch.memberId);
            const days = [1, 2, 3, 4, 5, 6].filter((d) =>
              sch.slots.some((s) => s.dayOfWeek === d),
            );
            return (
              <button
                key={sch.id}
                type="button"
                onClick={() => open({ type: "schedule", id: sch.id })}
                className="rounded-3xl bg-surface p-5 text-left card-shadow tap"
              >
                <div className="mb-3 flex items-center gap-3">
                  {member ? <MemberAvatar member={member} size="sm" /> : null}
                  <div>
                    <p className="font-display text-lg font-semibold">{sch.name}</p>
                    <p className="text-sm text-muted">
                      {member?.firstName} · {sch.slots.length} créneaux
                    </p>
                  </div>
                </div>
                <div className="grid gap-2 sm:grid-cols-2">
                  {days.map((d) => (
                    <div key={d}>
                      <p className="text-xs font-bold uppercase text-muted">{weekdayLabel(d)}</p>
                      {sch.slots
                        .filter((s) => s.dayOfWeek === d)
                        .sort((a, b) => a.startTime.localeCompare(b.startTime))
                        .map((s) => (
                          <p key={s.id} className="text-sm">
                            <span className="font-semibold tabular-nums">{s.startTime}</span>{" "}
                            {s.subject}
                            {s.room ? ` · ${s.room}` : ""}
                          </p>
                        ))}
                    </div>
                  ))}
                </div>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
