import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Phone, Trash2 } from "lucide-react";
import { useMemo } from "react";
import { toast } from "sonner";
import { ColorPicker } from "@/components/forms";
import { AvatarPicker, MemberAvatar } from "@/components/member-avatar";
import { useEditors } from "@/components/editors-context";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { fileToStoredDataUrl } from "@/lib/family/files";
import { ageOn } from "@/lib/family/dates";
import { useFamilyStore } from "@/lib/family/store";
import { EMPTY_HEALTH, EMPTY_SCHOOL } from "@/lib/family/types";
import type { FamilyMember, MemberColor } from "@/lib/family/types";

export const Route = createFileRoute("/membre/$memberId")({
  component: MemberPage,
});

function MemberPage() {
  const { memberId } = Route.useParams();
  const navigate = useNavigate();
  // Sélecteurs stables (pas de .find/.filter dans le selector → évite boucle #185)
  const members = useFamilyStore((s) => s.members);
  const allContacts = useFamilyStore((s) => s.contacts);
  const updateMember = useFamilyStore((s) => s.updateMember);
  const removeMember = useFamilyStore((s) => s.removeMember);
  const healthUnlocked = useFamilyStore((s) => s.settings.healthUnlocked);
  const updateSettings = useFamilyStore((s) => s.updateSettings);
  const { open } = useEditors();

  const raw = useMemo(
    () => members.find((m) => m.id === memberId),
    [members, memberId],
  );
  const contacts = useMemo(
    () => allContacts.filter((c) => c.memberId === memberId),
    [allContacts, memberId],
  );

  // Données persistées anciennes peuvent manquer school/health
  const member = useMemo(() => {
    if (!raw) return null;
    return {
      ...raw,
      school: { ...EMPTY_SCHOOL, ...raw.school, usefulLinks: raw.school?.usefulLinks ?? [] },
      health: { ...EMPTY_HEALTH, ...raw.health },
    };
  }, [raw]);

  if (!member) {
    return (
      <div className="rounded-2xl bg-surface p-6 card-shadow">
        <p>Membre introuvable.</p>
        <Link to="/famille" className="mt-3 inline-block font-semibold text-primary">
          Retour à la famille
        </Link>
      </div>
    );
  }

  const age = ageOn(member.birthDate);

  function patch<K extends keyof FamilyMember>(key: K, value: FamilyMember[K]) {
    updateMember(memberId, { [key]: value } as Partial<FamilyMember>);
  }

  async function onPhoto(file?: File) {
    if (!file) return;
    try {
      const dataUrl = await fileToStoredDataUrl(file);
      updateMember(memberId, { photo: dataUrl });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Photo trop lourde");
    }
  }

  return (
    <div className="flex flex-col gap-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <Link to="/famille" className="text-sm font-semibold text-muted">
          ← Ma famille
        </Link>
        {members.length > 1 ? (
          <Button
            variant="danger"
            size="sm"
            onClick={() => {
              if (confirm(`Supprimer ${member.firstName} ?`)) {
                removeMember(member.id);
                toast.success("Membre retiré");
                void navigate({ to: "/famille" });
              }
            }}
          >
            <Trash2 className="size-4" />
            Supprimer
          </Button>
        ) : null}
      </div>

      <header className="flex items-center gap-4 rounded-[1.6rem] bg-surface p-5 card-shadow">
        <label className="cursor-pointer">
          <MemberAvatar member={member} size="xl" />
          <input
            type="file"
            accept="image/*"
            className="sr-only"
            onChange={(e) => void onPhoto(e.target.files?.[0])}
          />
        </label>
        <div>
          <h1 className="font-display text-3xl font-extrabold">
            {member.firstName} {member.lastName}
          </h1>
          <p className="text-sm font-semibold text-muted">
            {age != null ? `${age} ans` : "Âge à calculer"} · touchez la photo pour la changer
          </p>
        </div>
      </header>

      <MemberSnapshot memberId={memberId} />

      <Section title="Informations personnelles">
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Prénom">
            <Input value={member.firstName} onChange={(e) => patch("firstName", e.target.value)} />
          </Field>
          <Field label="Nom">
            <Input value={member.lastName} onChange={(e) => patch("lastName", e.target.value)} />
          </Field>
          <Field label="Surnom">
            <Input value={member.nickname} onChange={(e) => patch("nickname", e.target.value)} />
          </Field>
          <Field label="Rôle">
            <Select
              value={member.role}
              onChange={(e) => patch("role", e.target.value as FamilyMember["role"])}
            >
              <option value="parent">Parent</option>
              <option value="enfant">Enfant</option>
              <option value="autre">Autre</option>
            </Select>
          </Field>
          <Field label="Date de naissance">
            <Input
              type="date"
              value={member.birthDate}
              onChange={(e) => patch("birthDate", e.target.value)}
            />
          </Field>
          <Field label="Téléphone">
            <Input
              type="tel"
              value={member.phone}
              onChange={(e) => patch("phone", e.target.value)}
            />
          </Field>
          <Field label="Email">
            <Input
              type="email"
              value={member.email}
              onChange={(e) => patch("email", e.target.value)}
            />
          </Field>
          <Field label="Adresse">
            <Input value={member.address} onChange={(e) => patch("address", e.target.value)} />
          </Field>
        </div>
        <Field label="Notes personnelles">
          <Textarea value={member.notes} onChange={(e) => patch("notes", e.target.value)} />
        </Field>
        <Field label="Couleur">
          <ColorPicker
            value={member.color}
            onChange={(c: MemberColor) => patch("color", c)}
          />
        </Field>
        <Field label="Avatar (choisis ton personnage)">
          <AvatarPicker
            value={member.avatar || ""}
            onChange={(a) => patch("avatar", a)}
          />
        </Field>
      </Section>

      <Section title="École / études">
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Établissement">
            <Input
              value={member.school.name}
              onChange={(e) =>
                patch("school", { ...member.school, name: e.target.value })
              }
            />
          </Field>
          <Field label="Adresse de l'établissement">
            <Input
              value={member.school.address}
              onChange={(e) =>
                patch("school", { ...member.school, address: e.target.value })
              }
            />
          </Field>
          <Field label="Classe">
            <Input
              value={member.school.className}
              onChange={(e) =>
                patch("school", { ...member.school, className: e.target.value })
              }
            />
          </Field>
          <Field label="Niveau">
            <Input
              value={member.school.level}
              onChange={(e) =>
                patch("school", { ...member.school, level: e.target.value })
              }
            />
          </Field>
          <Field label="Professeur principal">
            <Input
              value={member.school.headTeacher}
              onChange={(e) =>
                patch("school", { ...member.school, headTeacher: e.target.value })
              }
            />
          </Field>
          <Field label="Horaires">
            <Input
              value={member.school.hours}
              onChange={(e) =>
                patch("school", { ...member.school, hours: e.target.value })
              }
            />
          </Field>
        </div>
        <Field label="Informations importantes">
          <Textarea
            value={member.school.important}
            onChange={(e) =>
              patch("school", { ...member.school, important: e.target.value })
            }
          />
        </Field>
        <Field label="Lien utile (URL)">
          <Input
            value={member.school.usefulLinks[0]?.url ?? ""}
            placeholder="https://"
            onChange={(e) =>
              patch("school", {
                ...member.school,
                usefulLinks: [
                  {
                    id: member.school.usefulLinks[0]?.id ?? "link-1",
                    label: member.school.usefulLinks[0]?.label || "Lien",
                    url: e.target.value,
                  },
                ],
              })
            }
          />
        </Field>
      </Section>

      <Section title="Santé">
        <p className="mb-3 text-sm text-muted">
          Informations privées, stockées uniquement sur cet appareil. Ne sont jamais publiées.
        </p>
        {!healthUnlocked ? (
          <Button variant="outline" onClick={() => updateSettings({ healthUnlocked: true })}>
            Afficher les informations de santé
          </Button>
        ) : (
          <div className="flex flex-col gap-3">
            <Field label="Allergies">
              <Textarea
                value={member.health.allergies}
                onChange={(e) =>
                  patch("health", { ...member.health, allergies: e.target.value })
                }
              />
            </Field>
            <Field label="Médecin traitant">
              <Input
                value={member.health.gp}
                onChange={(e) => patch("health", { ...member.health, gp: e.target.value })}
              />
            </Field>
            <Field label="Autres médecins">
              <Input
                value={member.health.otherDoctors}
                onChange={(e) =>
                  patch("health", { ...member.health, otherDoctors: e.target.value })
                }
              />
            </Field>
            <Field label="Traitements">
              <Textarea
                value={member.health.treatments}
                onChange={(e) =>
                  patch("health", { ...member.health, treatments: e.target.value })
                }
              />
            </Field>
            <Field label="Groupe sanguin">
              <Input
                value={member.health.bloodType}
                onChange={(e) =>
                  patch("health", { ...member.health, bloodType: e.target.value })
                }
              />
            </Field>
            <Field label="Personnes à contacter en urgence">
              <Textarea
                value={member.health.emergencyContacts}
                onChange={(e) =>
                  patch("health", { ...member.health, emergencyContacts: e.target.value })
                }
              />
            </Field>
            <Field label="Notes médicales">
              <Textarea
                value={member.health.notes}
                onChange={(e) =>
                  patch("health", { ...member.health, notes: e.target.value })
                }
              />
            </Field>
            <Button variant="ghost" onClick={() => updateSettings({ healthUnlocked: false })}>
              Masquer à nouveau
            </Button>
          </div>
        )}
      </Section>

      <Section title="Contacts importants">
        <div className="flex flex-col gap-2">
          {contacts.map((c) => (
            <div
              key={c.id}
              className="flex items-center justify-between gap-3 rounded-2xl bg-surface-2 px-3 py-3"
            >
              <button
                type="button"
                className="min-w-0 text-left"
                onClick={() => open({ type: "contact", id: c.id, memberId })}
              >
                <p className="font-semibold">{c.name}</p>
                <p className="text-sm text-muted">{c.kind} {c.phone ? `· ${c.phone}` : ""}</p>
              </button>
              {c.phone ? (
                <a
                  href={`tel:${c.phone}`}
                  className="flex size-11 items-center justify-center rounded-full bg-accent text-accent-fg"
                  aria-label={`Appeler ${c.name}`}
                >
                  <Phone className="size-4" />
                </a>
              ) : null}
            </div>
          ))}
        </div>
        <Button
          className="mt-3"
          variant="outline"
          onClick={() => open({ type: "contact", memberId })}
        >
          Ajouter un contact
        </Button>
      </Section>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-[1.6rem] bg-surface p-5 card-shadow">
      <h2 className="mb-4 font-display text-xl font-extrabold">{title}</h2>
      <div className="flex flex-col gap-3">{children}</div>
    </section>
  );
}

function MemberSnapshot({ memberId }: { memberId: string }) {
  const events = useFamilyStore((s) => s.events);
  const tasks = useFamilyStore((s) => s.tasks);
  const documents = useFamilyStore((s) => s.documents);
  const { open } = useEditors();
  const today = new Date().toISOString().slice(0, 10);
  const todayEvents = events.filter(
    (e) =>
      e.date === today &&
      (e.wholeFamily || e.memberIds.includes(memberId)),
  );
  const openTasks = tasks.filter(
    (t) => t.status !== "done" && (t.assigneeId === memberId || t.assigneeId === null),
  );
  const docs = documents.filter((d) => d.memberId === memberId).slice(0, 3);

  return (
    <section className="grid gap-2 sm:grid-cols-3">
      <button
        type="button"
        onClick={() => open({ type: "event", memberId })}
        className="rounded-[1.4rem] bg-member-violet-soft px-4 py-3 text-left"
      >
        <p className="font-display text-2xl font-extrabold tabular-nums">{todayEvents.length}</p>
        <p className="text-xs font-bold text-member-violet-fg">Aujourd'hui</p>
      </button>
      <button
        type="button"
        onClick={() => open({ type: "task" })}
        className="rounded-[1.4rem] bg-member-vert-soft px-4 py-3 text-left"
      >
        <p className="font-display text-2xl font-extrabold tabular-nums">{openTasks.length}</p>
        <p className="text-xs font-bold text-member-vert-fg">Tâches</p>
      </button>
      <button
        type="button"
        onClick={() => open({ type: "document" })}
        className="rounded-[1.4rem] bg-member-bleu-soft px-4 py-3 text-left"
      >
        <p className="font-display text-2xl font-extrabold tabular-nums">{docs.length}</p>
        <p className="text-xs font-bold text-member-bleu-fg">Documents</p>
      </button>
    </section>
  );
}
