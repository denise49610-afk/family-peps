import { useEffect } from "react";
import { useFamilyStore } from "@/lib/family/store";
import { initCloudSync } from "@/lib/family/sync";

/** Rehydrate localStorage then start optional cloud sync. Client-only. */
export function FamilyHydrator() {
  useEffect(() => {
    const api = useFamilyStore.persist;
    const start = () => initCloudSync();
    void api.rehydrate();
    if (api.hasHydrated()) {
      start();
      return;
    }
    return api.onFinishHydration(start);
  }, []);
  return null;
}
