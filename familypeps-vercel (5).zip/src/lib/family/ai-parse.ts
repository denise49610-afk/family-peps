import { uid } from "@/lib/utils";
import type { ScheduleSlot } from "./types";
import { flattenDays, parseTimetableText } from "./parse-schedule";

export type AiSlot = {
  dayOfWeek: number;
  startTime: string;
  endTime: string;
  subject: string;
  room: string;
  teacher: string;
};

/**
 * Analyse locale : texte + OCR image (Tesseract) si dispo.
 * Pas de backend requis — tout tourne dans le navigateur.
 */
export async function parseScheduleWithAi(input: {
  text?: string;
  imageDataUrl?: string;
}): Promise<{ ok: true; slots: AiSlot[]; source: string } | { ok: false; error: string; slots: AiSlot[] }> {
  let text = (input.text || "").trim();

  // OCR navigateur si photo fournie et peu/pas de texte
  if (input.imageDataUrl && text.length < 40) {
    try {
      const ocr = await ocrImage(input.imageDataUrl);
      if (ocr.trim().length > text.length) {
        text = ocr;
      }
    } catch {
      // OCR optionnel — on continue avec le texte
    }
  }

  if (!text.trim()) {
    return { ok: false, error: "empty", slots: [] };
  }

  const days = parseTimetableText(text);
  const slots = flattenDays(days).map((s) => ({
    dayOfWeek: s.dayOfWeek,
    startTime: s.startTime,
    endTime: s.endTime,
    subject: s.subject,
    room: s.room,
    teacher: s.teacher,
  }));

  if (!slots.length) {
    return { ok: false, error: "no-slots", slots: [] };
  }

  return {
    ok: true,
    slots,
    source: input.imageDataUrl ? "Photo / OCR" : "Texte",
  };
}

async function ocrImage(dataUrl: string): Promise<string> {
  // Chargement dynamique pour ne pas alourdir le premier écran
  const mod = await import("tesseract.js");
  const worker = await mod.createWorker("fra+eng");
  try {
    const {
      data: { text },
    } = await worker.recognize(dataUrl);
    return text || "";
  } finally {
    await worker.terminate();
  }
}

export function aiSlotsToSchedule(
  slots: AiSlot[],
  memberId: string,
  name = "Emploi du temps (import)",
) {
  return {
    id: uid("sch"),
    memberId,
    name,
    slots: slots.map(
      (s): ScheduleSlot => ({
        id: uid("slot"),
        dayOfWeek: s.dayOfWeek,
        startTime: s.startTime,
        endTime: s.endTime,
        subject: s.subject,
        room: s.room,
        teacher: s.teacher,
      }),
    ),
  };
}
