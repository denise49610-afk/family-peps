import { uid } from "@/lib/utils";
import type { ScheduleSlot } from "./types";

const DAY_MAP: Record<string, number> = {
  dimanche: 0,
  dim: 0,
  lundi: 1,
  lun: 1,
  mardi: 2,
  mar: 2,
  mercredi: 3,
  mer: 3,
  jeudi: 4,
  jeu: 4,
  vendredi: 5,
  ven: 5,
  samedi: 6,
  sam: 6,
};

export type ParsedDay = {
  dayOfWeek: number;
  label: string;
  slots: ScheduleSlot[];
};

const TIME_RE =
  /(\d{1,2})\s*[hH:]\s*(\d{2})?(?:\s*[-–àto]+\s*(\d{1,2})\s*[hH:]\s*(\d{2})?)?/;

function pad(n: number): string {
  return String(n).padStart(2, "0");
}

function toHHMM(h: string, m?: string): string {
  return `${pad(Number(h))}:${pad(Number(m || "0"))}`;
}

function addHour(hhmm: string): string {
  const [h, m] = hhmm.split(":").map(Number);
  const next = (h + 1) % 24;
  return `${pad(next)}:${pad(m)}`;
}

export function parseTimetableText(text: string): ParsedDay[] {
  const lines = text
    .replace(/\r/g, "\n")
    .split("\n")
    .map((l) => l.trim())
    .filter(Boolean);

  const days: ParsedDay[] = [];
  let current: ParsedDay | null = null;

  for (const raw of lines) {
    const lower = raw.toLowerCase().replace(/[.]/g, "");
    const dayHit = Object.keys(DAY_MAP).find(
      (k) =>
        lower === k ||
        lower.startsWith(k + " ") ||
        lower.startsWith(k + ":") ||
        lower.startsWith(k + "-") ||
        lower.startsWith(k + "/"),
    );
    // Ligne "Lundi" seule ou "Lundi 08h Maths"
    if (dayHit && (raw.length < 28 || TIME_RE.test(raw))) {
      current = {
        dayOfWeek: DAY_MAP[dayHit],
        label: dayHit,
        slots: [],
      };
      days.push(current);
      // Si la même ligne contient aussi un horaire, on continue le parse
      if (!TIME_RE.test(raw) || raw.length < 12) continue;
    }
    const tm = raw.match(TIME_RE);
    if (!tm || !current) continue;
    const start = toHHMM(tm[1], tm[2]);
    const end = tm[3] ? toHHMM(tm[3], tm[4]) : addHour(start);
    let rest = raw.replace(tm[0], " ").replace(/[|]/g, " ").trim();
    rest = rest.replace(/^[-–:]+/, "").trim();
    const roomMatch = rest.match(
      /(?:salle|s\.?|room)\s*[:.]?\s*([A-Za-z0-9-]+)/i,
    );
    const teacherMatch = rest.match(
      /(?:m\.|mme|prof(?:esseur)?)\s+([A-Za-zÀ-ÿ' -]{2,})/i,
    );
    let subject = rest
      .replace(/(?:salle|s\.?|room)\s*[:.]?\s*[A-Za-z0-9-]+/i, "")
      .replace(/(?:m\.|mme|prof(?:esseur)?)\s+[A-Za-zÀ-ÿ' -]{2,}/i, "")
      .replace(/\s{2,}/g, " ")
      .replace(/^[-–•]+/, "")
      .trim();
    if (!subject) subject = "Cours";
    current.slots.push({
      id: uid("slot"),
      dayOfWeek: current.dayOfWeek,
      startTime: start,
      endTime: end,
      subject,
      room: roomMatch?.[1] ?? "",
      teacher: teacherMatch?.[1]?.trim() ?? "",
    });
  }

  return days.filter((d) => d.slots.length > 0);
}

export function flattenDays(days: ParsedDay[]): ScheduleSlot[] {
  return days.flatMap((d) => d.slots);
}

export function extractPdfStrings(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  const text = new TextDecoder("latin1").decode(bytes);
  const chunks: string[] = [];
  const re = /\((?:\\.|[^\\)]){2,}\)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text))) {
    const inner = m[0].slice(1, -1).replace(/\\n/g, "\n").replace(/\\\)/g, ")");
    if (/[A-Za-zÀ-ÿ]/.test(inner)) chunks.push(inner);
  }
  return chunks.join("\n");
}
