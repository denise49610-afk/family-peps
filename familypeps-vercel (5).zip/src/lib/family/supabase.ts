import { createClient, type SupabaseClient } from "@supabase/supabase-js";

const url = (import.meta.env.VITE_SUPABASE_URL as string | undefined)?.trim();
const anon = (import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined)?.trim();

/** true si les variables d'env Netlify / .env sont présentes au BUILD */
export function isCloudConfigured(): boolean {
  return Boolean(url && anon && url.startsWith("https://") && anon.length > 20);
}

export function cloudConfigHint(): string {
  if (!url && !anon) return "Variables VITE_SUPABASE_* absentes du build (redeploy Netlify requis)";
  if (!url) return "VITE_SUPABASE_URL manquante";
  if (!anon) return "VITE_SUPABASE_ANON_KEY manquante";
  if (!url.startsWith("https://")) return "VITE_SUPABASE_URL doit commencer par https://";
  if (url.endsWith("/")) return "Enlève le / final de VITE_SUPABASE_URL";
  return "OK";
}

export function explainNetworkError(e: unknown): string {
  const msg = e instanceof Error ? e.message : String(e);
  if (/failed to fetch|networkerror|load failed|fetch/i.test(msg)) {
    return [
      "Impossible de joindre Supabase (Failed to fetch).",
      "Vérifie :",
      "1) VITE_SUPABASE_URL = https://XXXX.supabase.co (sans / à la fin)",
      "2) Projet Supabase non en pause (dashboard → Restore si besoin)",
      "3) SQL schema.sql bien exécuté",
      "4) Pas de bloqueur pub / VPN qui coupe l'API",
      "5) Nouveau build Netlify après avoir mis les variables",
    ].join(" ");
  }
  return msg;
}

let client: SupabaseClient | null = null;

export function getSupabase(): SupabaseClient | null {
  if (!isCloudConfigured()) return null;
  if (!client) {
    client = createClient(url!, anon!, {
      auth: { persistSession: false, autoRefreshToken: false },
      realtime: { params: { eventsPerSecond: 5 } },
    });
  }
  return client;
}

/** Test rapide : table families accessible ? */
export async function testCloudConnection(): Promise<{ ok: true; url: string } | { error: string }> {
  const sb = getSupabase();
  if (!sb) return { error: cloudConfigHint() };
  try {
    const { error } = await sb.from("families").select("code").limit(1);
    if (error) {
      if (error.message.includes("relation") || error.code === "42P01") {
        return { error: "Table families absente — exécute supabase/schema.sql dans SQL Editor" };
      }
      if (/jwt|api key|invalid/i.test(error.message)) {
        return { error: "Clé anon invalide — recolle VITE_SUPABASE_ANON_KEY (Project Settings → API)" };
      }
      return { error: error.message };
    }
    return { ok: true, url: url! };
  } catch (e) {
    return { error: explainNetworkError(e) };
  }
}
