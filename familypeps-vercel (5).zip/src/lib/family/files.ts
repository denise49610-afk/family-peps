const MAX_BYTES = 4_500_000; // ~3–4 Mo après base64, plus tolérant mobile

export function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("Lecture du fichier impossible"));
    reader.readAsDataURL(file);
  });
}

export async function compressImage(
  file: File,
  maxEdge = 1600,
  quality = 0.78,
): Promise<string> {
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const image = new Image();
      image.onload = () => resolve(image);
      image.onerror = () =>
        reject(
          new Error(
            "Image non lisible (HEIC/iPhone ?). Dans Photos, partagez en JPEG ou PNG, ou choisissez « Image ».",
          ),
        );
      image.src = url;
    });
    const scale = Math.min(1, maxEdge / Math.max(img.width, img.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(img.width * scale));
    canvas.height = Math.max(1, Math.round(img.height * scale));
    const ctx = canvas.getContext("2d");
    if (!ctx) return readFileAsDataUrl(file);
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL("image/jpeg", quality);
  } finally {
    URL.revokeObjectURL(url);
  }
}

export async function fileToStoredDataUrl(file: File): Promise<string> {
  const isImage =
    file.type.startsWith("image/") ||
    /\.(jpe?g|png|gif|webp|bmp)$/i.test(file.name);

  // HEIC souvent non supporté par le canvas navigateur
  if (/heic|heif/i.test(file.type) || /\.heic$/i.test(file.name)) {
    throw new Error(
      "Format HEIC (iPhone) non supporté ici. Dans Photos : partager → « Enregistrer en JPEG », ou Réglages iPhone → Appareil photo → Formats → « Le plus compatible ».",
    );
  }

  let dataUrl = isImage ? await compressImage(file) : await readFileAsDataUrl(file);

  if (isImage && dataUrl.length > MAX_BYTES) {
    dataUrl = await compressImage(file, 1100, 0.6);
  }
  if (isImage && dataUrl.length > MAX_BYTES) {
    dataUrl = await compressImage(file, 900, 0.5);
  }
  if (dataUrl.length > MAX_BYTES) {
    throw new Error(
      "Fichier trop volumineux (max ~3 Mo). Compressez le PDF ou choisissez une photo plus légère.",
    );
  }
  return dataUrl;
}

export function downloadDataUrl(dataUrl: string, name: string) {
  const a = document.createElement("a");
  a.href = dataUrl;
  a.download = name;
  a.rel = "noopener";
  document.body.appendChild(a);
  a.click();
  a.remove();
}
