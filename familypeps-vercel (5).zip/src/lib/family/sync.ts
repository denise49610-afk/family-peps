import type { FamilyState } from "./types";
import { explainNetworkError, getSupabase, isCloudConfigured } from "./supabase";
import { useFamilyStore } from "./store";

const STATE_KEYS: (keyof FamilyState)[] = [
  "settings",
  "members",
  "events",
  "tasks",
  "activities",
  "schedules",
  "documents",
  "notes",
  "infos",
  "contacts",
  "categories",
];

function snapshotState(s: FamilyState): FamilyState {
  const out = {} as FamilyState;
  for (const k of STATE_KEYS) {
    (out as any)[k] = s[k];
  }
  // Ne pas synchroniser le code famille depuis le payload distant pour éviter boucles
  return out;
}

function applyRemotePayload(payload: FamilyState) {
  const local = useFamilyStore.getState();
  const nextSettings = {
    ...payload.settings,
    // conserver préférences locales sensibles
    healthUnlocked: local.settings.healthUnlocked,
    currentMemberId:
      payload.settings?.currentMemberId ||
      local.settings.currentMemberId ||
      payload.members?.[0]?.id ||
      "",
    familyCode: local.settings.familyCode,
    cloudSync: local.settings.cloudSync,
  };
  useFamilyStore.setState({
    ...snapshotState(payload),
    settings: nextSettings,
  });
}

/** Génère un code famille court (ex: PEPS-A3F9) */
export function generateFamilyCode(): string {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let body = "";
  for (let i = 0; i < 4; i++) {
    body += alphabet[Math.floor(Math.random() * alphabet.length)];
  }
  return `PEPS-${body}`;
}

export type SyncStatus = "off" | "connecting" | "synced" | "error";

let pushing = false;
let applyingRemote = false;
let pushTimer: ReturnType<typeof setTimeout> | null = null;
let channel: ReturnType<NonNullable<ReturnType<typeof getSupabase>>["channel"]> | null = null;
let unsubStore: (() => void) | null = null;
let statusListeners = new Set<(s: SyncStatus, msg?: string) => void>();
let currentStatus: SyncStatus = "off";

function setStatus(s: SyncStatus, msg?: string) {
  currentStatus = s;
  statusListeners.forEach((fn) => fn(s, msg));
}

export function getSyncStatus() {
  return currentStatus;
}

export function onSyncStatus(fn: (s: SyncStatus, msg?: string) => void) {
  statusListeners.add(fn);
  fn(currentStatus);
  return () => {
    statusListeners.delete(fn);
  };
}

async function pushNow(code: string) {
  const sb = getSupabase();
  if (!sb || applyingRemote) return;
  pushing = true;
  try {
    const state = snapshotState(useFamilyStore.getState());
    const { error } = await sb.from("families").upsert({
      code,
      payload: state,
      updated_at: new Date().toISOString(),
    });
    if (error) {
      setStatus("error", error.message);
    } else {
      setStatus("synced");
    }
  } catch (e) {
    setStatus("error", e instanceof Error ? e.message : "Erreur sync");
  } finally {
    pushing = false;
  }
}

function schedulePush(code: string) {
  if (pushTimer) clearTimeout(pushTimer);
  pushTimer = setTimeout(() => {
    void pushNow(code);
  }, 600);
}

/** Crée une famille cloud et y pousse l'état local */
export async function createFamilyCloud(): Promise<{ code: string } | { error: string }> {
  if (!isCloudConfigured()) {
    return { error: "Supabase non configuré (variables VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY)" };
  }
  const code = generateFamilyCode();
  const sb = getSupabase()!;
  const state = snapshotState(useFamilyStore.getState());
  try {
    const { error } = await sb.from("families").insert({
      code,
      payload: state,
      updated_at: new Date().toISOString(),
    });
    if (error) return { error: error.message };
  } catch (e) {
    return { error: explainNetworkError(e) };
  }
  useFamilyStore.getState().updateSettings({ familyCode: code, cloudSync: true });
  await startSync(code);
  return { code };
}

/** Rejoint une famille existante (remplace l'état local par le cloud) */
export async function joinFamilyCloud(rawCode: string): Promise<{ ok: true } | { error: string }> {
  if (!isCloudConfigured()) {
    return { error: "Supabase non configuré (variables VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY)" };
  }
  const code = rawCode.trim().toUpperCase();
  if (!code) return { error: "Code vide" };
  const sb = getSupabase()!;
  let data: { payload?: FamilyState } | null = null;
  try {
    const res = await sb.from("families").select("payload").eq("code", code).maybeSingle();
    if (res.error) return { error: res.error.message };
    data = res.data as { payload?: FamilyState } | null;
  } catch (e) {
    return { error: explainNetworkError(e) };
  }
  if (!data?.payload) return { error: "Code introuvable" };
  applyingRemote = true;
  try {
    applyRemotePayload(data.payload as FamilyState);
    useFamilyStore.getState().updateSettings({ familyCode: code, cloudSync: true });
  } finally {
    applyingRemote = false;
  }
  await startSync(code);
  return { ok: true };
}

export async function leaveFamilyCloud() {
  stopSync();
  useFamilyStore.getState().updateSettings({ familyCode: "", cloudSync: false });
  setStatus("off");
}

/** Démarre écoute realtime + push local → cloud */
export async function startSync(code?: string) {
  const sb = getSupabase();
  const familyCode = (code || useFamilyStore.getState().settings.familyCode || "").trim().toUpperCase();
  if (!sb || !familyCode || !useFamilyStore.getState().settings.cloudSync) {
    setStatus("off");
    return;
  }

  stopSync(false);
  setStatus("connecting");

  // Charge dernière version
  const { data, error } = await sb.from("families").select("payload, updated_at").eq("code", familyCode).maybeSingle();
  if (error) {
    setStatus("error", error.message);
    return;
  }
  if (data?.payload) {
    applyingRemote = true;
    try {
      applyRemotePayload(data.payload as FamilyState);
      useFamilyStore.getState().updateSettings({ familyCode, cloudSync: true });
    } finally {
      applyingRemote = false;
    }
  } else {
    // Première poussée si la ligne n'existe pas encore
    await pushNow(familyCode);
  }

  channel = sb
    .channel(`family:${familyCode}`)
    .on(
      "postgres_changes",
      { event: "*", schema: "public", table: "families", filter: `code=eq.${familyCode}` },
      (payload) => {
        if (pushing) return;
        const row = payload.new as { payload?: FamilyState } | null;
        if (!row?.payload) return;
        applyingRemote = true;
        try {
          applyRemotePayload(row.payload);
        } finally {
          applyingRemote = false;
        }
        setStatus("synced");
      },
    )
    .subscribe((status) => {
      if (status === "SUBSCRIBED") setStatus("synced");
      if (status === "CHANNEL_ERROR") setStatus("error", "Realtime déconnecté");
    });

  unsubStore = useFamilyStore.subscribe(() => {
    if (applyingRemote || pushing) return;
    const s = useFamilyStore.getState().settings;
    if (!s.cloudSync || !s.familyCode) return;
    schedulePush(s.familyCode);
  });
}

export function stopSync(updateStatus = true) {
  if (pushTimer) {
    clearTimeout(pushTimer);
    pushTimer = null;
  }
  if (unsubStore) {
    unsubStore();
    unsubStore = null;
  }
  const sb = getSupabase();
  if (channel && sb) {
    void sb.removeChannel(channel);
    channel = null;
  }
  if (updateStatus) setStatus("off");
}

/** À appeler une fois au démarrage (après hydrate) */
export function initCloudSync() {
  if (!isCloudConfigured()) {
    setStatus("off");
    return;
  }
  const { familyCode, cloudSync } = useFamilyStore.getState().settings;
  if (cloudSync && familyCode) {
    void startSync(familyCode);
  }
}
