-- Family Peps — à coller dans Supabase → SQL Editor → Run

create table if not exists public.families (
  code text primary key,
  payload jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.families enable row level security;

drop policy if exists "families_select" on public.families;
drop policy if exists "families_insert" on public.families;
drop policy if exists "families_update" on public.families;

create policy "families_select" on public.families
  for select using (true);

create policy "families_insert" on public.families
  for insert with check (true);

create policy "families_update" on public.families
  for update using (true);

-- Realtime (ignore si déjà ajouté)
do $$
begin
  alter publication supabase_realtime add table public.families;
exception
  when duplicate_object then null;
end $$;
